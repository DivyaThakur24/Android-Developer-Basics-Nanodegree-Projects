# Musical Structure App

##### 4th Project for [Android Basics Nanodegree by Google](https://www.udacity.com/course/android-basics-nanodegree-by-google--nd803)

### App description:

1. The app is a simple structure of Music App.
2. The first Fragment contains 4 categories.
3. Each category has the list of items to choose.
User is able to click on any item in the list and go to the list of songs.
4. By clicking on any the song, the the music player screen will appear.
5. From any activity in the app, user can go back to the previous page, using up button.
6. The second Fragment is an empty screen to imitate the place, where user will be able
store the favorites songs.
