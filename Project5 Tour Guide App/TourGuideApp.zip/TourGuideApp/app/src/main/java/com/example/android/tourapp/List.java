package com.example.android.tourapp;

class List {

    private int info;
    private int info2;
    private int info3;

    List(int info, int info2, int info3) {
        this.info = info;
        this.info2 = info2;
        this.info3 = info3;
    }

    int getInfo() {
        return info;
    }

    int getInfo2() {
        return info2;
    }

    int getInfo3() {
        return info3;
    }
}
